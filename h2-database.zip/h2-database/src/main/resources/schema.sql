
CREATE TABLE IF NOT EXISTS  management_locations(
manId VARCHAR(2) PRIMARY KEY,
location_name VARCHAR(20) NOT NULL);

CREATE TABLE IF NOT EXISTS MANAGERS (
    id INT AUTO_INCREMENT PRIMARY KEY,
    locId VARCHAR(2),
    first_name VARCHAR(250) NOT NULL,
    last_name VARCHAR(250) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    CONSTRAINT fk_locId FOREIGN KEY (locId) REFERENCES management_locations(manId)
);


CREATE TABLE IF NOT EXISTS earthquake_log(
e_date VARCHAR(20), 
e_location_name VARCHAR(20),
e_magnitude VARCHAR(20));




/**
CREATE TABLE IF NOT EXISTS TBL_EMPLOYEES (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  first_name VARCHAR(250) NOT NULL,
  last_name VARCHAR(250) NOT NULL,
  email VARCHAR(250) DEFAULT NULL
);

**/
