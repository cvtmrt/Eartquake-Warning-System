INSERT INTO MANAGEMENT_LOCATIONS(MANID, LOCATION_NAME)
 VALUES
( '01', 'ADANA'),
( '02', 'ANTALYA'),
( '03', 'BURSA'),
( '04', 'DİYARBAKIR'),
( '05', 'ELAZIĞ'),
( '06', 'ERZURUM'),
( '07', 'ESKİŞEHİR'),
( '08', 'GAZİANTEP'),
( '09', 'İSTANBUL'),
( '10', 'İZMİR'),
( '11', 'KAYSERİ'),
( '12', 'KASTAMONU'),
( '13', 'KONYA'),
( '14', 'SAMSUN'),
( '15', 'SİVAS'),
( '16', 'TRABZON'),
( '17', 'VAN');

INSERT INTO MANAGERS (locId, first_name, last_name, phone) 
VALUES
  ('00', 'okay', 'computing', '0558848484'),
  ('01', 'spring', 'h2db', '05581238484'),
  ('12', 'CAGRI', 'BABA', '0551235684'),
  ('08', 'KUTAY', 'BABAA', '05511233684'),
  ('04', 'MERTCAN', 'BABAAA', '055131245');


