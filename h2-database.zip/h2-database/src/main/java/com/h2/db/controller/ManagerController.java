package com.h2.db.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.h2.db.exception.RecordNotFoundException;
import com.h2.db.model.ManagerEntity;
import com.h2.db.service.ManagerService;

@Controller
@RequestMapping("/")
public class ManagerController 
{
	@Autowired
	ManagerService service;

	@RequestMapping
	@Transactional
	public String getAllManagers(Model model) 
	{	
		System.out.println("getAllManagers");
		
		List<ManagerEntity> list = service.getAllManagers();
		System.out.println("list" +list);

		model.addAttribute("managers", list);
		return "list-managers";
	}

	
	
	
	@RequestMapping(path = {"/edit", "/edit/{id}"})
	public String editManagerById(Model model, @PathVariable("id") Optional<Long> id) 
							throws RecordNotFoundException 
	{
		
		System.out.println("editManagerById" + id);
		if (id.isPresent()) {
			ManagerEntity entity = service.getManagerById(id.get());
			model.addAttribute("manager", entity);
		} else {
			model.addAttribute("manager", new ManagerEntity());
		}
		
		
		return "add-edit-manager";
	}
	
	@RequestMapping(path = "/delete/{id}")
	public String deleteManagerById(Model model, @PathVariable("id") Long id) 
							throws RecordNotFoundException 
	{
		
		System.out.println("deleteManagerById" + id);
		
		service.deleteManagerById(id);
		return "redirect:/";
	}

	@RequestMapping(path = "/createManager", method = RequestMethod.POST)
	public String createOrUpdateManager(ManagerEntity manager) 
	{
		System.out.println("createOrUpdateManager ");
		
		service.createOrUpdateManager(manager);
		
		return "redirect:/";
	}
}
