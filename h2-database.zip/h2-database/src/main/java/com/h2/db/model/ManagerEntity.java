package com.h2.db.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MANAGERS")
public class ManagerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "locId", length = 2, nullable = false)
    private String locId;
    
    @Column(name="first_name")
    private String firstName;
     
    @Column(name="last_name")
    private String lastName;
    
    @Column(name="phone", length = 20, nullable = false)
    private String phone;
    
    
    
    
    
    public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getLocId() {
		return locId;
	}



	public void setLocId(String locId) {
		this.locId = locId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}


	@Override
    public String toString() {
        return "ManagerEntity [id=" + id + ", firstName=" + firstName + ", locId=" + locId + ", lastName=" + lastName
                + ", phone=" + phone + "]";
    }   
}
