package com.h2.db.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.h2.db.exception.RecordNotFoundException;
import com.h2.db.model.ManagerEntity;
import com.h2.db.model.repository.ManagerRepository;


@Service
public class ManagerService {
	
	@Autowired
	ManagerRepository repository;
	
	public List<ManagerEntity> getAllManagers()
	{
		System.out.println("getAllManagers");
		List<ManagerEntity> result = (List<ManagerEntity>) repository.findAll();
		
		if(result.size() > 0) {
			return result;
		} else {
			return new ArrayList<ManagerEntity>();
		}
	}

	
	public ManagerEntity getManagerById(Long id) throws RecordNotFoundException 
	{
		System.out.println("getEmployeeById");
		Optional<ManagerEntity> manager = repository.findById(id);
		
		if(manager.isPresent()) {
			return manager.get();
		} else {
			throw new RecordNotFoundException("No employee record exist for given id");
		}
	}
	
	
	  public ManagerEntity createOrUpdateManager(ManagerEntity entity) {
	  System.out.println("createOrUpdateManager"); // Create new entry
	  if(entity.getId() == null) { entity = repository.save(entity);
	  
	  return entity; } else { // update existing entry Optional<EmployeeEntity>
	 Optional<ManagerEntity>  manager = repository.findById(entity.getId());
	  
	  if(manager.isPresent()) { ManagerEntity newEntity = manager.get();
	  newEntity.setLocId(entity.getLocId());
	  newEntity.setPhone(entity.getPhone());
	  newEntity.setFirstName(entity.getFirstName());
	  newEntity.setLastName(entity.getLastName());
	  
	  newEntity = repository.save(newEntity);
	  
	  return newEntity; } else { entity = repository.save(entity);
	  
	  return entity; } } }
	 
	
	
	  public void deleteManagerById(Long id) throws RecordNotFoundException {
	  System.out.println("deleteManagerById");
	  
	  Optional<ManagerEntity> manager = repository.findById(id);
	  
	  if(manager.isPresent()) { repository.deleteById(id); } else { throw new
	  RecordNotFoundException("No employee record exist for given id"); } }
	 
}