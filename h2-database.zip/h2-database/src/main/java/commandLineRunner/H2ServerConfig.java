package commandLineRunner;

import org.h2.tools.Server;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.sql.SQLException;

@Configuration
public class H2ServerConfig {

    @Bean
    public CommandLineRunner startH2Server() {
        return args -> {
            try {
                Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "9092").start();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        };
    }
}

