package Assets;

// Earthquake class to hold earthquake data
class Earthquake {
    String date;       // Date of the earthquake
    String magnitude;  // Magnitude of the earthquake
    String location;   // Location of the earthquake

    // Constructor to initialize the earthquake data
    public Earthquake(String date, String magnitude, String location) {
        this.date = date;
        this.magnitude = magnitude;
        this.location = location;
    }

    // Getter method for the date
    public String getDate() {
        return date;
    }

    // Setter method for the date
    public void setDate(String date) {
        this.date = date;
    }
}
