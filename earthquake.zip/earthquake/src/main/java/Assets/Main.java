package Assets;


import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {

	private final static int SystemRepeatSecondFrequency = 10; // System checks earthquake data every x seconds
	private final static int SystemClearRepeatHoursFrequency = 1; // System check logs, list, and sets data every x hours to clear
	public static Database database = new Database(); // Database instance for storing and managing earthquake data
	public static DataParser parser = new DataParser(); // DataParser instance for parsing earthquake data
	public static EarthquakeSys Sys = new EarthquakeSys(); // EarthquakeSys instance for managing earthquake system operations

	public static void main(String[] args) {
		// Create a ScheduledExecutorService with a thread pool of size 1
		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

		// Initial parsing and printing of all earthquake data occurred in the last 24 hours
		parser.AllEarthquakeDataParser();
		Sys.printAllEarthquakes();

		// Schedule a task to run every SystemRepeatSecondFrequency seconds
		scheduler.scheduleAtFixedRate(() -> {
			// Parse and check the last 5 earthquakes
			parser.last5EarthquakeDataParser();	
		}, 0, SystemRepeatSecondFrequency, TimeUnit.SECONDS);

		// Schedule a task to run every hour
		scheduler.scheduleAtFixedRate(() -> {
			// Clear processed earthquake set if the earthquake date exceeds 48 hours
			Sys.clearProcessedEarthquakesDate();
			// Clear harmful earthquake set if the earthquake date exceeds 48 hours
			Sys.ClearAllHarmfulearthquakes();
			// Clear earthquake log if the earthquake date exceeds 48 hours
			database.checkAndDeleteOldEarthquakes();
		}, 0, SystemClearRepeatHoursFrequency, TimeUnit.HOURS);
		
		
		
	}
}
