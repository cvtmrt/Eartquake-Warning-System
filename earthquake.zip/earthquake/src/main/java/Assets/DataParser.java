package Assets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class DataParser {

    private static final String urlString = "http://www.koeri.boun.edu.tr/scripts/lst2.asp"; // URL to fetch earthquake data
    private static TimeZone timeZone = TimeZone.getTimeZone("Europe/Istanbul"); // Time zone for Istanbul
    private static Calendar calendar = Calendar.getInstance(timeZone); // Calendar instance with Istanbul time zone
    private static Date currentDate = calendar.getTime(); // Current date and time in Istanbul

    // Method to parse all earthquake data
    public void AllEarthquakeDataParser() {

        EarthquakeSys Sys = Main.Sys; // Instance of EarthquakeSys from Main class
        Database database = Main.database; // Instance of Database from Main class

        String exloc;
        int locCheck;

        try {
            // Create a URL object
            URL url = new URL(urlString);
            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Set the request method to GET
            connection.setRequestMethod("GET");

            // Get the response code from the server
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) { // If the request was successful
                // Create a BufferedReader to read the response
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                // Read the response line by line
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine).append("\n");
                }
                in.close();

                // Split the response into lines
                String[] lines = response.toString().split("\n");
                for (String line : lines) {
                    // Skip empty lines or lines that do not match the expected format
                    if (line.trim().isEmpty() || !line.matches("\\d{4}\\.\\d{2}\\.\\d{2}.*")) {
                        continue; // Skip empty or unnecessary lines
                    }

                    // Split the line into parts
                    String[] parts = line.trim().split("\\s+");
                    String dateCheck = parts[0];

                    // Check if the earthquake occurred within 48 hours
                    if (isWithin48Hours(dateCheck)) {
                        // Extract date and time
                        String date = parts[0] + " " + parts[1];
                        // Extract magnitude
                        String magnitude = parts[6];
                        // Extract location
                        StringBuilder locationBuilder = new StringBuilder();
                        for (int i = 8; i < parts.length - 1; i++) {
                            locationBuilder.append(parts[i]).append(" ");
                        }
                        String location = locationBuilder.toString().trim();

                        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.US);
                        dateFormatter.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul"));

                        Date earthquakeDate = dateFormatter.parse(date);

                        // Calculate the time difference
                        long timeDifference = currentDate.getTime() - earthquakeDate.getTime();

                        // Check if the earthquake magnitude is above the specified value
                        if (Double.parseDouble(magnitude) >= Sys.LeastCheckMagnitudeValue) {
                            // Check if the earthquake occurred within the specified time range
                            if (timeDifference <= Sys.TimeRangeBetweenNowAndEarthquake && timeDifference >= 0) {
                                if (!database.ifMatchDatesFromEarthquake_log(date)) {
                                    exloc = Sys.extractLocation(location);
                                    locCheck = database.findLocation(exloc);
                                    if (locCheck != 0) {
                                        database.insertEarthquakeSms(date, exloc, magnitude);
                                    }
                                }
                                // Add new earthquake's date to processed earthquakes set
                                Sys.processedEarthquakesDate.add(date);

                                // Add all harmful earthquakes to the list
                                Sys.AllHarmfulearthquakes.add(new Earthquake(date, magnitude, location));
                            }
                        }
                    } else {
                        break; // Exit the loop if the earthquake is not within 48 hours
                    }
                } // End of for loop
            } else {
                System.out.println("GET request failed. Response Code: " + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to parse the data of the last x earthquakes// currently it checks last 5
    public void last5EarthquakeDataParser() {

        List<String> filteredLines = new ArrayList<>();
        boolean foundNewEarthquake = false;
        String line;
        Database database = Main.database; // Instance of Database from Main class
        EarthquakeSys Sys = Main.Sys; // Instance of EarthquakeSys from Main class
        String exloc;
        int locCheck;

        try {
            // Create a URL object
            URL url = new URL(urlString);
            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Set the request method to GET
            connection.setRequestMethod("GET");

            // Get the response code from the server
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) { // If the request was successful
                // Create a BufferedReader to read the response
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;

                // Read and filter the response lines
                while ((inputLine = in.readLine()) != null) {
                    if (!inputLine.trim().isEmpty() && inputLine.matches("\\d{4}\\.\\d{2}\\.\\d{2}.*")) {
                        filteredLines.add(inputLine);
                    }
                }
                in.close();

                // Last five earthquake checks
                for (int a = 0; a < Sys.CheckslastXEarthquakesData; a++) {
                    line = filteredLines.get(a);

                    // Split the line into parts
                    String[] parts = line.trim().split("\\s+");
                    // Extract date and time
                    String date = parts[0] + " " + parts[1];
                    // Extract magnitude
                    String magnitude = parts[6];
                    // Extract location
                    StringBuilder locationBuilder = new StringBuilder();
                    for (int i = 8; i < parts.length - 1; i++) {
                        locationBuilder.append(parts[i]).append(" ");
                    }
                    String location = locationBuilder.toString().trim();

                    SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.US);
                    dateFormatter.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul"));

                    Date earthquakeDate = dateFormatter.parse(date);

                    // Calculate the time difference
                    long timeDifference = currentDate.getTime() - earthquakeDate.getTime();

                    String dateCheck = parts[0];

                    // Check if the earthquake occurred within 48 hours
                    if (isWithin48Hours(dateCheck)) {
                        // Check if the earthquake magnitude is above the specified value
                        if (Double.parseDouble(magnitude) >= Sys.LeastCheckMagnitudeValue) {
                            // Check if the earthquake occurred within the specified time range
                            if (timeDifference <= Sys.TimeRangeBetweenNowAndEarthquake && timeDifference >= 0) {
                                if (!Sys.processedEarthquakesDate.contains(date)) {
                                    // Add new earthquake's date to processed earthquakes set
                                    
                                	Sys.processedEarthquakesDate.add(date);
                                    // Print earthquake details and add to harmful earthquakes list
                                    Sys.printEarthquake(new Earthquake(date, magnitude, location));
                                    Sys.AllHarmfulearthquakes.add(new Earthquake(date, magnitude, location));

                                    // Save earthquake log
                                    exloc = Sys.extractLocation(location);
                                    locCheck = database.findLocation(exloc);
                                    if (locCheck != 0) {
                                        database.insertEarthquakeSms(date, exloc, magnitude);
                                    }

                                    // Set flag indicating a new earthquake was found
                                    foundNewEarthquake = true;
                                }
                            }
                        }
                    }
                }
                // If no recent earthquake was found, print a message
                if (!foundNewEarthquake) {
                    System.out.println("No new earthquakes detected.");
                }
            } else {
                System.out.println("GET request failed. Response Code: " + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to check if a date is within the last 48 hours
    public boolean isWithin48Hours(String date) {
        LocalDate currentDateOfMonth = LocalDate.now();
        int currentDayOfMonth = currentDateOfMonth.getDayOfMonth();
        String[] dateParts = date.split("\\.");
        int day = Integer.parseInt(dateParts[2]);
        int dayDifferenceOfMonth = currentDayOfMonth - day;
        return dayDifferenceOfMonth == 0 || dayDifferenceOfMonth == 1;
    }
}
