package Assets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Database {
    // JDBC URL, username, and password of the H2 database
    private static final String DATABASE_URL = "jdbc:h2:tcp://localhost:9092/~/sample"; // replace ~/test with your database path
    private static final String USER = "sa"; // replace with your username if different
    private static final String PASSWORD = ""; // replace with your password if any
    // Method to find the location ID based on earthquake location name
    public int findLocation(String earthLoc) {
        int found_loc_id = 0;

        
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT MANID, location_name FROM management_locations")) {

               while (rs.next()) {
                   int grpid = rs.getInt("MANID");
                   String locname = rs.getString("location_name");
                   if (earthLoc.equalsIgnoreCase(locname)) {
                       found_loc_id = grpid;
                       break; // Exit loop if a match is found
                   }
               }

               

           } catch (SQLException e) {
               e.printStackTrace();
           }
       

        return found_loc_id;
    }

    // Method to get phone numbers of managers based on location ID
    public void getPhonesFromLocation_id(int location_id) {
    	EarthquakeSys Sys = Main.Sys;
        String CheckId;
        if (location_id < 10) {
            CheckId = "0" + location_id;
        } else {
            CheckId = Integer.toString(location_id);
        }

        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String sql = "SELECT phone FROM MANAGERS WHERE locId = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, CheckId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString("phone"));
                Sys.phoneNumberToSendSms.add(rs.getString("phone")); // Add phone number to list
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        System.out.println();
    }

    // Method to insert earthquake data into the database
 // Static method to insert earthquake SMS data
    public static void insertEarthquakeSms(String earthquakedate, String loc_Name, String magnitude) {
        String insertSQL = "INSERT INTO earthquake_log (e_date, e_location_name, e_magnitude) VALUES(?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            // Set the values for the PreparedStatement
            pstmt.setString(1, earthquakedate);
            pstmt.setString(2, loc_Name);
            pstmt.setString(3, magnitude);

            // Execute the insertion
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

 // Method to check if an earthquake date already exists in the database
    public boolean ifMatchDatesFromEarthquake_log(String edate) {
        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String sql = "SELECT e_date FROM earthquake_log WHERE e_date = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Set the parameter before executing the query
            pstmt.setString(1, edate);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                // Use .equals() to compare strings
                if (edate.equals(rs.getString("e_date"))) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public void checkAndDeleteOldEarthquakes() {
        TimeZone timeZone = TimeZone.getTimeZone("Europe/Istanbul");
        Calendar calendar = Calendar.getInstance(timeZone);
        Date currentDate = calendar.getTime();
        EarthquakeSys Sys = Main.Sys;

        try (Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String edate;

            // Prepare statement to select and delete older entries
            String sqlSelect = "SELECT e_date FROM earthquake_log";
            PreparedStatement pstmtSelect = conn.prepareStatement(sqlSelect);
            ResultSet rs = pstmtSelect.executeQuery();

            while (rs.next()) {
                edate = rs.getString("e_date");

                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.US);
                dateFormatter.setTimeZone(TimeZone.getTimeZone("Europe/Istanbul"));
                Date earthquakeDate = null;
                try {
                    earthquakeDate = dateFormatter.parse(edate);
                } catch (ParseException e) {
                    e.printStackTrace();
                    continue; // Skip this entry if parsing fails
                }

                long timeDifference = currentDate.getTime() - earthquakeDate.getTime();
                // Check if the date is older than the specified offset
                if (!(timeDifference <= (Sys.LogDeleteHoursOffSet * 60 * 60 * 1000) && timeDifference >= 0)) {
                    // Delete the row
                    String sqlDelete = "DELETE FROM earthquake_log WHERE e_date = ?";
                    PreparedStatement pstmtDelete = conn.prepareStatement(sqlDelete);
                    pstmtDelete.setString(1, edate);
                    pstmtDelete.executeUpdate();
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
