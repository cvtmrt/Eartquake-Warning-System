package Assets;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class EarthquakeSys {

	private static final long constant = 60 * 1000; // constant value to use in TimeRangeBetweenNowAndEarthquake variable

	public static String locationOfEarthquake = null; // Location of the current earthquake
	public static Set<String> processedEarthquakesDate = new HashSet<>(); // Set of processed earthquake dates
	public List<Earthquake> AllHarmfulearthquakes = new ArrayList<>(); // List of harmful earthquakes
	public Set<String> phoneNumberToSendSms = new HashSet<>(); // Set of phone numbers to send SMS
	public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss"); // Date formatter
	
	public final static Double LeastCheckMagnitudeValue = 2.0; // Minimum magnitude value to check
	public long TimeRangeBetweenNowAndEarthquake = 1000 * constant; // Time range between now and earthquake time in minutes
	public final int CheckslastXEarthquakesData = 5; // Number of recent earthquakes to check
    public final int LogDeleteHoursOffSet = 48; //Delete logs if earthquake dates exceeds x hours
    private static final int DeleteListAndSetHours = 48; //Delete Earthquake list and Eartquakes'date set if earthquake dates exceeds x hours
	
    static Database database = Main.database; // Database instance from the Main class

	// Method to print all harmful earthquakes
	public void printAllEarthquakes() {
		// Iterate through the list of earthquakes
		for (Earthquake earthquake : AllHarmfulearthquakes) {
			printEarthquake(earthquake);
		}
	}

	// Method to print the details of a single earthquake
	public static void printEarthquake(Earthquake earthquakeprint) {
		int found_loc_id = 0;

		// Extract the location of the earthquake
		locationOfEarthquake = extractLocation(earthquakeprint.location);
		System.out.println("There is a new earthquake with magnitude greater than " + LeastCheckMagnitudeValue);
		System.out.println("Location: " + locationOfEarthquake);
		System.out.println("Magnitude: " + earthquakeprint.magnitude);
		System.out.println("Earthquake date: " + earthquakeprint.date);
		System.out.println();

		// Find the location ID in the database
		found_loc_id = database.findLocation(locationOfEarthquake);

		if (found_loc_id != 0) {
			System.out.println("There is an ilbank management in the: " + locationOfEarthquake + "\nfound_loc_id = " + found_loc_id);
			System.out.println();
			System.out.println("SMS warning messages will be sent to these numbers:");
			database.getPhonesFromLocation_id(found_loc_id);
		} else {
			System.out.println("There is no ilbank management in the: " + locationOfEarthquake);
			System.out.println();
		}
	}

	// Method to extract the location from a given string
	static String extractLocation(String location) {
		int startIndex = location.indexOf('(');
		int endIndex = location.indexOf(')');
		if (startIndex != -1 && endIndex != -1 && startIndex < endIndex) {
			return location.substring(startIndex + 1, endIndex);
		} else {
			return location;
		}
	}

	// Method to clear processed earthquake dates if they exceed 48 hours
	public Set<String> clearProcessedEarthquakesDate() {
		Set<String> updatedSet = new HashSet<>(processedEarthquakesDate);
		LocalDateTime now = LocalDateTime.now();

		Iterator<String> iterator = updatedSet.iterator();
		while (iterator.hasNext()) {
			String dateString = iterator.next();
			try {
				LocalDateTime date = LocalDateTime.parse(dateString, DATE_FORMAT);
				long diffInHours = ChronoUnit.HOURS.between(date, now);
				if (diffInHours > DeleteListAndSetHours) {
					iterator.remove();
				}
			} catch (Exception e) {
				e.printStackTrace(); // Handle the exception properly in real code
			}
		}
		processedEarthquakesDate = updatedSet;
		return processedEarthquakesDate;
	}

	// Method to clear all harmful earthquakes if they exceed 48 hours
	public List<Earthquake> ClearAllHarmfulearthquakes() {
		List<Earthquake> updatedAllHarmfulList = new ArrayList<>(AllHarmfulearthquakes);
		LocalDateTime now = LocalDateTime.now();

		Iterator<Earthquake> iterator = updatedAllHarmfulList.iterator();
		while (iterator.hasNext()) {
			Earthquake earthquake = iterator.next();
			try {
				LocalDateTime date = LocalDateTime.parse(earthquake.getDate(), DATE_FORMAT);
				long diffInHours = ChronoUnit.HOURS.between(date, now);
				if (diffInHours > DeleteListAndSetHours) {
					iterator.remove();
				}
			} catch (Exception e) {
				e.printStackTrace(); // Handle the exception properly in real code
			}
		}
		AllHarmfulearthquakes = updatedAllHarmfulList;
		return AllHarmfulearthquakes;
	}
}
