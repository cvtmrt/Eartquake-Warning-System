package Frames;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;


public class MainFrame extends JFrame {

	 // JDBC URL, username, and password of the H2 database
    public static final String pathToDataBase = "jdbc:h2:tcp://localhost:9092/~/sample";
    public static final String USER = "sa"; // replace with your username if different
    public static final String PASSWORD = ""; // replace with your password if any
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainFrame frame = new MainFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public MainFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 200, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("İlbank Admin Panel");
        lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 20));
        lblNewLabel.setBounds(124, 6, 234, 58);
        contentPane.add(lblNewLabel);

        JButton AddManagement = new JButton("Add Management");
        AddManagement.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
              
            	EarthquakeAddManagementFrame ManagementFrame = new EarthquakeAddManagementFrame();
            	ManagementFrame.setVisible(true);
                dispose(); // Dispose current frame if that's your intended behavior
        	}
        });
        AddManagement.setBounds(58, 122, 153, 29);
        contentPane.add(AddManagement);

        JButton btnAddManager = new JButton("Add Manager");
        btnAddManager.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	  EarthquakeAddManagerFrame ManagerFrame = new EarthquakeAddManagerFrame();
            	  ManagerFrame.setVisible(true);
                dispose(); // Dispose current frame if that's your intended behavior
            }
        });
        btnAddManager.setBounds(240, 122, 153, 29);
        contentPane.add(btnAddManager);
        
        JButton btnDeleteManager = new JButton("Delete Manager");
        btnDeleteManager.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		EarthquakeDeleteManager deleteManager = new EarthquakeDeleteManager();
        		deleteManager.setVisible(true);
                dispose(); // Dispose current frame if that's your intended behavior
        	}
        });
        btnDeleteManager.setBounds(152, 174, 153, 29);
        contentPane.add(btnDeleteManager);
    }
}
