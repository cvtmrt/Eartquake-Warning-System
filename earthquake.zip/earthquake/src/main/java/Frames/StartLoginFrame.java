package Frames;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.*;

public class StartLoginFrame extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JLabel wrong;

   
    private MainFrame mainFrm;
    private JButton btnCancel;

    public StartLoginFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 200, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Enter Password:");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
        lblNewLabel.setBounds(66, 103, 134, 22);
        contentPane.add(lblNewLabel);

        wrong = new JLabel("");
        wrong.setForeground(new Color(255, 0, 0));
        wrong.setBounds(147, 135, 107, 13);
        contentPane.add(wrong);

        textField = new JTextField();
        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    login();
                }
            }
        });
        textField.setFont(new Font("Tahoma", Font.BOLD, 14));
        textField.setBounds(200, 103, 152, 22);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Log In");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnNewButton.setBounds(249, 160, 107, 30);
        contentPane.add(btnNewButton);
        
        
        JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame mainFrame = new MainFrame();
				mainFrame.setVisible(true);
				dispose();
			}
		});
        btnCancel.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnCancel.setBounds(85, 154, 117, 29);
        contentPane.add(btnCancel);
    }

    private void login() {
        String password = textField.getText();
        if (password.equalsIgnoreCase("admin")) {
        	mainFrm = new MainFrame();
        	mainFrm.setVisible(true);
            dispose(); // Close the login frame
        } else {
            wrong.setText("Wrong Password!");
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    StartLoginFrame frame = new StartLoginFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
