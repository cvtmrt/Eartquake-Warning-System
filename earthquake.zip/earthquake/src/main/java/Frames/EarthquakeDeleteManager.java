package Frames;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class EarthquakeDeleteManager extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static class ComboBoxManagers {
        private String first_name;
        private String last_name;

        public ComboBoxManagers(String first_name, String last_name) {
            this.first_name = first_name;
            this.last_name = last_name;
        }

        public String getFirstName() {
            return first_name;
        }

        public String getLastName() {
            return last_name;
        }

        @Override
        public String toString() {
            return first_name + " " + last_name;
        }
    }

    public static class ComboBoxManagement {
        private String grpid;
        private String locname;

        public ComboBoxManagement(String grpid, String locname) {
            this.grpid = grpid;
            this.locname = locname;
        }

        public String getGrpid() {
            return grpid;
        }

        public String getLocname() {
            return locname;
        }

        @Override
        public String toString() {
            return locname;
        }
    }

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                EarthquakeDeleteManager frame = new EarthquakeDeleteManager();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public EarthquakeDeleteManager() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 200, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true);
                dispose();
            }
        });
        btnCancel.setBounds(68, 212, 117, 29);
        contentPane.add(btnCancel);

        JComboBox<ComboBoxManagers> comboBoxmanager = new JComboBox<>(new DefaultComboBoxModel<>());
        comboBoxmanager.setBounds(223, 59, 196, 27);
        contentPane.add(comboBoxmanager);

        JComboBox<ComboBoxManagement> comboBoxmanagement = new JComboBox<>(new DefaultComboBoxModel<>());
        comboBoxmanagement.setBounds(55, 59, 130, 27);
        contentPane.add(comboBoxmanagement);

        loadManagementLocations(comboBoxmanagement);

        JButton btnNewButton = new JButton("Delete");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ComboBoxManagers selectedManager = (ComboBoxManagers) comboBoxmanager.getSelectedItem();
                if (selectedManager == null) {
                    JOptionPane.showMessageDialog(null, "Please select manager", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String Fname = selectedManager.getFirstName();
                String Lname = selectedManager.getLastName();
                String manphone = getPhoneFromName(Fname, Lname);

                DeleteManager(manphone);

                // Refresh the managers list in the combo box
                ComboBoxManagement selectedManagement = (ComboBoxManagement) comboBoxmanagement.getSelectedItem();
                if (selectedManagement != null) {
                    loadManagers(comboBoxmanager, selectedManagement.getGrpid());
                }
            }
        });
        btnNewButton.setBounds(263, 212, 117, 29);
        contentPane.add(btnNewButton);

        comboBoxmanagement.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ComboBoxManagement selectedManagement = (ComboBoxManagement) comboBoxmanagement.getSelectedItem();
                if (selectedManagement != null) {
                    loadManagers(comboBoxmanager, selectedManagement.getGrpid());
                }
            }
        });

        comboBoxmanager.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ComboBoxManagers selectedManager = (ComboBoxManagers) comboBoxmanager.getSelectedItem();
                if (selectedManager != null) {
                    
                }
            }
        });
    }

    private void loadManagementLocations(JComboBox<ComboBoxManagement> comboBox) {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT MANID, location_name FROM management_locations")) {

            while (rs.next()) {
                String grpid = rs.getString("MANID");
                String locname = rs.getString("location_name");
                ComboBoxManagement management = new ComboBoxManagement(grpid, locname);
                comboBox.addItem(management);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadManagers(JComboBox<ComboBoxManagers> comboBox, String grpid) {
        comboBox.removeAllItems();
        try (Connection conn = getConnection()) {
            String sql = "SELECT first_name, last_name FROM managers WHERE locId = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, grpid);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String first_name = rs.getString("first_name");
                String last_name = rs.getString("last_name");
                ComboBoxManagers manager = new ComboBoxManagers(first_name, last_name);
                comboBox.addItem(manager);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void DeleteManager(String mphone) {
    	String pathToDataBase = MainFrame.pathToDataBase;
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        String deleteSQL = "DELETE FROM managers WHERE phone = ?";
        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {

            // Set the value for the PreparedStatement
            pstmt.setString(1, mphone);

            // Execute the deletion
            pstmt.executeUpdate();
            System.out.println("Data has been deleted successfully.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static String getPhoneFromName(String fName, String lName) {
    	String pathToDataBase = MainFrame.pathToDataBase;
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        String sql = "SELECT phone FROM managers WHERE first_name = ? AND last_name = ?";
        String phone = null;

        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // Set the values for the PreparedStatement
            pstmt.setString(1, fName);
            pstmt.setString(2, lName);

            // Execute the query
            ResultSet rs = pstmt.executeQuery();

            // Process the ResultSet
            if (rs.next()) {
                phone = rs.getString("phone");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return phone;
    }

    private Connection getConnection() throws SQLException {
    	String pathToDataBase = MainFrame.pathToDataBase;
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        return DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
    }
}
