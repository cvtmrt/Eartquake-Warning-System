package Frames;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class EarthquakeAddManagerFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JLabel successful;

	/**
	 * Launch the application.
	 * 
	 * 
	 */
	
	public class ComboBoxItem {
	    private String grpid;
	    private String locname;

	    public ComboBoxItem(String grpid, String locname) {
	        this.grpid = grpid;
	        this.locname = locname;
	    }

	    public String getGrpid() {
	        return grpid;
	    }

	    public String getLocname() {
	        return locname;
	    }

	    @Override
	    public String toString() {
	        return locname;
	    }
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EarthquakeAddManagerFrame frame = new EarthquakeAddManagerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public EarthquakeAddManagerFrame() {
		String pathToDataBase = MainFrame.pathToDataBase;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		successful = new JLabel("");
		successful.setForeground(new Color(0, 255, 0));
		successful.setBackground(new Color(0, 255, 0));
		successful.setBounds(182, 234, 137, 13);
		contentPane.add(successful);
		
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(102, 33, 61, 16);
		contentPane.add(lblName);
		
		textField = new JTextField();
		textField.setBounds(227, 28, 130, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setBounds(102, 72, 61, 16);
		contentPane.add(lblSurname);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(227, 67, 130, 26);
		contentPane.add(textField_1);
		
		JLabel lblPhone = new JLabel("phone");
		lblPhone.setBounds(102, 110, 61, 16);
		contentPane.add(lblPhone);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(227, 105, 130, 26);
		contentPane.add(textField_2);
		
		JLabel lblLocation = new JLabel("location");
		lblLocation.setBounds(102, 147, 61, 16);
		contentPane.add(lblLocation);
		
		
	;
		
		JComboBox<ComboBoxItem> comboBox = new JComboBox<>(new DefaultComboBoxModel<>());
        comboBox.setBounds(227, 143, 130, 27);
        contentPane.add(comboBox);
        
        comboBox.addActionListener(e -> {
            ComboBoxItem selectedItem = (ComboBoxItem) comboBox.getSelectedItem();
            if (selectedItem != null) {
                String selectedGrpid = selectedItem.getGrpid();
               
            }
        });

		
		JButton btnNewButton = new JButton("add manager");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String name = textField.getText().trim();
		        String surname = textField_1.getText().trim();
		        String phone = textField_2.getText().trim();
		        ComboBoxItem selectedId = (ComboBoxItem) comboBox.getSelectedItem();
		        String selectedGrpid = selectedId.getGrpid();
		        
		        
		       
		 
		       
		        
		        if (name.isEmpty() || surname.isEmpty() || phone.isEmpty() || selectedGrpid == null) {
		            JOptionPane.showMessageDialog(null, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

		        try {
		          
		            insertData(selectedGrpid, name, surname, phone);
		            successful.setText("Insert successful!");
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Invalid ID format", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		        
		        
			}
		});
		btnNewButton.setBounds(250, 205, 117, 29);
		contentPane.add(btnNewButton);
		
    	JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame mainFrame = new MainFrame();
				mainFrame.setVisible(true);
				dispose();
			}
		});
        btnCancel.setBounds(102, 205, 117, 29);
        contentPane.add(btnCancel);
        
       
       
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
		// Populate the combo box with values from the database
        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT MANID, location_name FROM management_locations")) {

        	while (rs.next()) {
                String grpid = rs.getString("MANID");
                String locname = rs.getString("location_name");
                ComboBoxItem item = new ComboBoxItem(grpid, locname);
                comboBox.addItem(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	private static void insertData(String id, String fName, String lname, String mphone) {
		String pathToDataBase = MainFrame.pathToDataBase;
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        String insertSQL = "INSERT INTO managers(locId, first_name, last_name, phone) VALUES(?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            // Set the values for the PreparedStatement
            pstmt.setString(1, id);
            pstmt.setString(2, fName);
            pstmt.setString(3, lname);
            pstmt.setString(4, mphone);

            // Execute the insertion
            pstmt.executeUpdate();
            System.out.println("Data has been inserted successfully.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
	}
	
	
}
