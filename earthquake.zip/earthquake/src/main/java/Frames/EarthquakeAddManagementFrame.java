package Frames;

import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EarthquakeAddManagementFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField_1;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    EarthquakeAddManagementFrame frame = new EarthquakeAddManagementFrame();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public EarthquakeAddManagementFrame() {
    	
    	String pathToDataBase = MainFrame.pathToDataBase;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 200, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Management id");
        lblNewLabel.setBounds(62, 62, 129, 16);
        contentPane.add(lblNewLabel);
        
        JLabel lblLocationName = new JLabel("Location Name");
        lblLocationName.setBounds(62, 104, 129, 16);
        contentPane.add(lblLocationName);

        JComboBox comboBox = new JComboBox();
        comboBox.setBounds(255, 58, 76, 27);
        contentPane.add(comboBox);
        
        String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        // find the last row of the management table and get the id value from the database
        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             Statement stmt = conn.createStatement();
        	    ResultSet LastRow = stmt.executeQuery("SELECT MANID FROM management_locations ORDER BY MANID DESC LIMIT 1")) {
            
        	if (LastRow.next()) {
                String bigid = LastRow.getString("MANID");
                int NextId = Integer.parseInt(bigid) + 1;
                comboBox.addItem(NextId);
            }
            
            
           
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
        JButton btnNewButton = new JButton("Add management");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
    		
		        String Location_name = textField_1.getText().trim();
		        int selectedId = (int) comboBox.getSelectedItem();
		        
		        String Next_id;
		        if (selectedId < 10) {
		        	Next_id = "0" + selectedId;
		        } else {
		        	Next_id = Integer.toString(selectedId);
		        }
		        
		        
		  
		        System.out.println("next_id: " + Next_id);
		        if (Location_name.isEmpty() || selectedId == 0) {
		            JOptionPane.showMessageDialog(null, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

		        try {
		           
		        	insertData(Next_id, Location_name);
		         
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Invalid ID format", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		        MainFrame mainFrame = new MainFrame();
		        mainFrame.setVisible(true);
				dispose();
			}
        	
        });
        btnNewButton.setBounds(232, 154, 146, 29);
        contentPane.add(btnNewButton);
        
    	JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame mainFrame = new MainFrame();
				mainFrame.setVisible(true);
				dispose();
			}
		});
        btnCancel.setBounds(85, 154, 117, 29);
        contentPane.add(btnCancel);
        
        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(232, 99, 130, 26);
        contentPane.add(textField_1);
        
    	
    }
    
    /**
     * Static method to insert data into the database.
     * @param location_name The name of the location to insert.
     */
    private static void insertData(String id, String location_name) {
    	String pathToDataBase = MainFrame.pathToDataBase;
    	String USER = MainFrame.USER;
    	String PASSWORD = MainFrame.PASSWORD;
        String insertSQL = "INSERT INTO management_locations(MANID, location_name) VALUES(?, ?)";
        try (Connection conn = DriverManager.getConnection(pathToDataBase, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            // Set the values for the PreparedStatement
        	pstmt.setString(1, id);
            pstmt.setString(2, location_name);

            // Execute the insertion
            pstmt.executeUpdate();
            System.out.println("Data has been inserted successfully.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
