package deneme;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class H2DatabaseConnection {
    // JDBC URL, username, and password of the H2 database
    private static final String JDBC_URL = "jdbc:h2:file:/Users/cvtmert/sample.mv.db"; // replace ~/test with your database path
    private static final String USER = "sa"; // replace with your username if different
    private static final String PASSWORD = ""; // replace with your password if any

    public static void main(String[] args) {
        Connection connection = null;
        try {
            // Attempt to establish a connection to the database
            connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
            System.out.println("Connection to H2 database established successfully.");
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur
            System.err.println("Failed to connect to H2 database.");
            e.printStackTrace();
        } finally {
            // Ensure the connection is closed to prevent resource leaks
            if (connection != null) {
                try {
                    connection.close();
                    System.out.println("Connection to H2 database closed successfully.");
                } catch (SQLException e) {
                    System.err.println("Failed to close the connection.");
                    e.printStackTrace();
                }
            }
        }
    }
}
